(function initContent(global) {
  if (global.__AI_TRANSLATE_CONTENT_READY__) {
    return;
  }
  global.__AI_TRANSLATE_CONTENT_READY__ = true;

  var root = global.AITranslate;
  var Constants = root.Constants;
  var Logger = root.Logger;
  var Segmenter = root.Segmenter;
  var DifficultPhrase = root.DifficultPhrase;
  var RuntimeClient = root.RuntimeClient;
  var TranslationGateway = root.TranslationGateway;

  var state = {
    options: null,
    pageTranslateEnabled: false,
    readingModeEnabled: false,
    pageSourceLang: "auto",
    pageTranslationArtifacts: [],
    pageProcessedElements: new WeakSet(),
    readingArtifacts: [],
    readingProcessedElements: new WeakSet(),
    readingProcessedKeyMap: {},
    lastReadingInsertedText: "",
    hoverTimer: null,
    lastHoverKey: "",
    scrollHandler: null,
    resizeHandler: null,
    mutationObserver: null,
    readingScrollHandler: null,
    readingResizeHandler: null,
    readingMutationObserver: null,
    translationCacheMap: {},
    translationCacheOrder: [],
    cachePersistTimer: null
  };

  function debounce(fn, wait) {
    var timer = null;
    return function () {
      var args = arguments;
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(function () {
        fn.apply(null, args);
      }, wait);
    };
  }

  async function getOptions() {
    var result = await RuntimeClient.sendMessage({ type: "get_options" });
    if (!result.ok) {
      Logger.warn("content", "get options failed");
      return Object.assign({}, Constants.DEFAULTS);
    }
    return Object.assign({}, Constants.DEFAULTS, result.data || {});
  }

  async function setPageState(patch) {
    await RuntimeClient.sendMessage({ type: "set_page_state", payload: patch });
  }

  async function loadTranslationCache() {
    return new Promise(function (resolve) {
      chrome.storage.local.get([Constants.CACHE.TRANSLATION_CACHE_KEY], function (result) {
        var cached = result[Constants.CACHE.TRANSLATION_CACHE_KEY];
        if (!cached || typeof cached !== "object") {
          state.translationCacheMap = {};
          state.translationCacheOrder = [];
          return resolve();
        }

        state.translationCacheMap = cached.map && typeof cached.map === "object" ? cached.map : {};
        state.translationCacheOrder = Array.isArray(cached.order) ? cached.order.filter(function (key) {
          return typeof key === "string" && state.translationCacheMap[key];
        }) : Object.keys(state.translationCacheMap);
        resolve();
      });
    });
  }

  function schedulePersistCache() {
    if (state.cachePersistTimer) {
      clearTimeout(state.cachePersistTimer);
    }

    state.cachePersistTimer = setTimeout(function () {
      var payload = {
        map: state.translationCacheMap,
        order: state.translationCacheOrder
      };
      var next = {};
      next[Constants.CACHE.TRANSLATION_CACHE_KEY] = payload;
      chrome.storage.local.set(next, function () {
        if (chrome.runtime.lastError) {
          Logger.warn("content", "persist translation cache failed", { error: chrome.runtime.lastError.message });
        }
      });
    }, 300);
  }

  function touchCacheKey(cacheKey) {
    var index = state.translationCacheOrder.indexOf(cacheKey);
    if (index >= 0) {
      state.translationCacheOrder.splice(index, 1);
    }
    state.translationCacheOrder.push(cacheKey);

    var maxEntries = Constants.CACHE.TRANSLATION_CACHE_MAX_ENTRIES;
    while (state.translationCacheOrder.length > maxEntries) {
      var removed = state.translationCacheOrder.shift();
      delete state.translationCacheMap[removed];
    }
  }

  function buildCacheKey(sourceLang, targetLang, text) {
    return [sourceLang, targetLang, text].join("||");
  }

  async function translateBlockWithCache(sourceLang, targetLang, text) {
    var clean = String(text || "").trim();
    if (!clean) {
      return null;
    }

    var cacheKey = buildCacheKey(sourceLang, targetLang, clean);
    if (state.translationCacheMap[cacheKey]) {
      touchCacheKey(cacheKey);
      return state.translationCacheMap[cacheKey];
    }

    var translated = await TranslationGateway.translateBlock(sourceLang, targetLang, clean);
    if (!translated) {
      return null;
    }

    state.translationCacheMap[cacheKey] = translated;
    touchCacheKey(cacheKey);
    schedulePersistCache();
    return translated;
  }

  function isElementVisible(element) {
    if (!element || !element.getBoundingClientRect) {
      return false;
    }

    if (element.getAttribute("aria-hidden") === "true") {
      return false;
    }

    var style = global.getComputedStyle ? global.getComputedStyle(element) : null;
    if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || Number(style.opacity) === 0)) {
      return false;
    }

    var rect = element.getBoundingClientRect();
    if (rect.width <= 0 && rect.height <= 0) {
      return false;
    }

    var margin = Constants.UI.VIEWPORT_MARGIN_PX;
    var viewTop = 0 - margin;
    var viewBottom = (global.innerHeight || document.documentElement.clientHeight || 0) + margin;
    return rect.bottom >= viewTop && rect.top <= viewBottom;
  }

  function removePageTranslationArtifacts() {
    var allBoxes = Array.prototype.slice.call(document.querySelectorAll(".ai-translate-page-box"));
    allBoxes.forEach(function (node) {
      if (node && node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    var translatedElements = Array.prototype.slice.call(document.querySelectorAll("[data-ai-translate-page-done='1']"));
    translatedElements.forEach(function (element) {
      element.removeAttribute("data-ai-translate-page-done");
    });

    state.pageTranslationArtifacts = [];
    state.pageProcessedElements = new WeakSet();
  }

  function collectPageTranslationCandidates(onlyVisible) {
    var selectors = "p,li,h1,h2,h3,h4,h5,h6,blockquote,figcaption,td,th";
    var elements = Array.prototype.slice.call(document.querySelectorAll(selectors));
    var candidates = [];

    for (var i = 0; i < elements.length; i += 1) {
      var element = elements[i];
      if (!element || state.pageProcessedElements.has(element)) {
        continue;
      }

      if (element.getAttribute("data-ai-translate-page-done") === "1") {
        continue;
      }

      var adjacent = element.nextElementSibling;
      if (adjacent && adjacent.classList && adjacent.classList.contains("ai-translate-page-box")) {
        element.setAttribute("data-ai-translate-page-done", "1");
        state.pageProcessedElements.add(element);
        continue;
      }

      if (element.closest(".ai-translate-page-box,.ai-translate-reading-box,.ai-translate-glossary,.ai-translate-hover-box,.ai-translate-selection-box,.ai-translate-banner")) {
        continue;
      }

      if (onlyVisible && !isElementVisible(element)) {
        continue;
      }

      var sourceText = String(element.innerText || "").replace(/\s+/g, " ").trim();
      if (sourceText.length < 12) {
        continue;
      }

      candidates.push({ element: element, text: sourceText });
      if (candidates.length >= Constants.UI.MAX_PAGE_NODES) {
        Logger.warn("content", "page translation candidate limit hit", { limit: Constants.UI.MAX_PAGE_NODES, onlyVisible: onlyVisible });
        break;
      }
    }

    return candidates;
  }

  async function detectPageSourceLangFromVisible() {
    var sampleItems = collectPageTranslationCandidates(true).slice(0, 8);
    var sample = sampleItems.map(function (item) {
      return item.text;
    }).join(" ");

    if (!sample) {
      return "auto";
    }

    return TranslationGateway.detectLanguage(sample);
  }

  async function renderPageTranslation(element, sourceText) {
    var translated = await translateBlockWithCache(state.pageSourceLang, state.options.targetLang || "zh", sourceText);
    if (!translated) {
      return;
    }

    var box = document.createElement("div");
    box.className = "ai-translate-page-box";
    box.textContent = translated;
    element.insertAdjacentElement("afterend", box);
    element.setAttribute("data-ai-translate-page-done", "1");
    state.pageTranslationArtifacts.push(box);
  }

  async function processVisiblePageCandidates() {
    if (!state.pageTranslateEnabled) {
      return;
    }

    var candidates = collectPageTranslationCandidates(true);
    var maxBatch = Constants.UI.PAGE_MODE_BATCH_SIZE;
    for (var i = 0; i < candidates.length && i < maxBatch; i += 1) {
      var item = candidates[i];
      state.pageProcessedElements.add(item.element);
      await renderPageTranslation(item.element, item.text);
    }
  }

  function unbindPageTranslateListeners() {
    if (state.scrollHandler) {
      global.removeEventListener("scroll", state.scrollHandler, { passive: true });
      state.scrollHandler = null;
    }

    if (state.resizeHandler) {
      global.removeEventListener("resize", state.resizeHandler);
      state.resizeHandler = null;
    }

    if (state.mutationObserver) {
      state.mutationObserver.disconnect();
      state.mutationObserver = null;
    }
  }

  function bindPageTranslateListeners() {
    var debouncedTranslate = debounce(function () {
      processVisiblePageCandidates();
    }, Constants.UI.SCROLL_TRANSLATE_DEBOUNCE_MS);

    state.scrollHandler = debouncedTranslate;
    state.resizeHandler = debouncedTranslate;

    global.addEventListener("scroll", state.scrollHandler, { passive: true });
    global.addEventListener("resize", state.resizeHandler);

    state.mutationObserver = new MutationObserver(function () {
      debouncedTranslate();
    });
    state.mutationObserver.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  async function enablePageTranslate() {
    if (state.pageTranslateEnabled) {
      await processVisiblePageCandidates();
      return;
    }

    var sourceLang = state.options.pageSourceLang || Constants.DEFAULTS.PAGE_SOURCE_LANG;
    if (sourceLang === "auto") {
      sourceLang = await detectPageSourceLangFromVisible();
      if (!sourceLang || sourceLang === "auto") {
        sourceLang = "auto";
      }
    }

    state.pageSourceLang = sourceLang;
    state.pageTranslateEnabled = true;

    bindPageTranslateListeners();
    await processVisiblePageCandidates();
    await setPageState({ pageTranslate: true, readingMode: false, activeMode: "page_translate" });
  }

  async function disablePageTranslate() {
    unbindPageTranslateListeners();
    removePageTranslationArtifacts();
    state.pageTranslateEnabled = false;
    state.pageSourceLang = "auto";
    await setPageState({ pageTranslate: false, activeMode: state.readingModeEnabled ? "reading_mode" : "none" });
  }

  function removeReadingArtifacts() {
    state.readingArtifacts.forEach(function (node) {
      if (node && node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    state.readingArtifacts = [];
    var translatedElements = Array.prototype.slice.call(document.querySelectorAll("[data-ai-reading-done='1']"));
    translatedElements.forEach(function (element) {
      element.removeAttribute("data-ai-reading-done");
    });
    state.lastReadingInsertedText = "";
  }

  function normalizeReadingInsertedText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function shouldSkipReadingInsert(nextText) {
    var normalized = normalizeReadingInsertedText(nextText);
    if (!normalized) {
      return true;
    }
    return normalized === state.lastReadingInsertedText;
  }

  function markReadingInsertedText(text) {
    state.lastReadingInsertedText = normalizeReadingInsertedText(text);
  }

  function insertReadingArtifactAfter(anchor, className, text) {
    if (!anchor || shouldSkipReadingInsert(text)) {
      return anchor;
    }

    var box = document.createElement("div");
    box.className = className;
    box.textContent = text;
    anchor.insertAdjacentElement("afterend", box);
    state.readingArtifacts.push(box);
    markReadingInsertedText(text);
    return box;
  }

  function isReadingCandidateVisible(element) {
    if (!element || !element.getBoundingClientRect) {
      return false;
    }

    if (element.getAttribute("aria-hidden") === "true") {
      return false;
    }

    var style = global.getComputedStyle ? global.getComputedStyle(element) : null;
    if (style && (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || Number(style.opacity) === 0)) {
      return false;
    }

    var rect = element.getBoundingClientRect();
    if (rect.width <= 0 && rect.height <= 0) {
      return false;
    }

    var margin = Constants.UI.VIEWPORT_MARGIN_PX;
    var viewTop = 0 - margin;
    var viewBottom = (global.innerHeight || document.documentElement.clientHeight || 0) + margin;
    return rect.bottom >= viewTop && rect.top <= viewBottom;
  }

  function buildElementPositionKey(element) {
    var parts = [];
    var cursor = element;
    var depth = 0;

    while (cursor && cursor !== document.body && depth < 12) {
      var tag = (cursor.tagName || "node").toLowerCase();
      var index = 1;
      var sibling = cursor;
      while (sibling && sibling.previousElementSibling) {
        sibling = sibling.previousElementSibling;
        if ((sibling.tagName || "").toLowerCase() === tag) {
          index += 1;
        }
      }
      parts.push(tag + ":" + index);
      cursor = cursor.parentElement;
      depth += 1;
    }

    return parts.reverse().join(">");
  }

  function buildReadingCandidateKey(element, text) {
    var positionKey = buildElementPositionKey(element);
    var textKey = String(text || "").replace(/\s+/g, " ").trim().slice(0, 220);
    return positionKey + "||" + textKey;
  }

  function hasNestedReadingTextBlock(element, onlyVisible) {
    if (!element || !element.querySelectorAll) {
      return false;
    }

    var nested = element.querySelectorAll("p,li,h1,h2,h3,h4,blockquote");
    for (var i = 0; i < nested.length; i += 1) {
      var node = nested[i];
      if (!node || node === element) {
        continue;
      }

      if (node.closest(".ai-translate-reading-box,.ai-translate-glossary,.ai-translate-hover-box,.ai-translate-selection-box")) {
        continue;
      }

      if (onlyVisible && !isReadingCandidateVisible(node)) {
        continue;
      }

      var nestedText = String(node.innerText || "").trim();
      if (nestedText.length >= 30) {
        return true;
      }
    }

    return false;
  }

  function collectReadingCandidates(onlyVisible) {
    var elements = Array.prototype.slice.call(document.querySelectorAll("p,li,h1,h2,h3,h4,blockquote"));
    var candidates = [];

    for (var i = 0; i < elements.length; i += 1) {
      var element = elements[i];
      if (!element || state.readingProcessedElements.has(element)) {
        continue;
      }

      if (element.getAttribute("data-ai-reading-done") === "1") {
        continue;
      }

      if (element.closest(".ai-translate-reading-box,.ai-translate-glossary,.ai-translate-hover-box,.ai-translate-selection-box")) {
        continue;
      }

      var text = String(element.innerText || "").trim();
      if (text.length < 30) {
        continue;
      }

      if (onlyVisible && !isReadingCandidateVisible(element)) {
        continue;
      }

      if (hasNestedReadingTextBlock(element, onlyVisible)) {
        continue;
      }

      var key = buildReadingCandidateKey(element, text);
      if (state.readingProcessedKeyMap[key]) {
        continue;
      }

      candidates.push({ element: element, text: text, key: key });
    }

    return candidates;
  }

  async function renderReadingHints(element, sourceText) {
    var anchor = element;
    var segmentText = Segmenter.toDelimitedText(sourceText, "  |  ");
    if (segmentText) {
      anchor = insertReadingArtifactAfter(anchor, "ai-translate-reading-box", segmentText);
    }

    var sourceLang = state.options.pageSourceLang || "auto";
    if (sourceLang === "auto") {
      sourceLang = await TranslationGateway.detectLanguage(sourceText.slice(0, 180));
    }

    var difficult = DifficultPhrase.extractCandidates(sourceText);
    if (difficult.length) {
      var hintRows = [];
      for (var i = 0; i < difficult.length; i += 1) {
        var item = difficult[i];
        var translated = await translateBlockWithCache(sourceLang, state.options.targetLang || "zh", item);
        if (!translated) {
          continue;
        }
        hintRows.push(item + " -> " + translated);
      }

      if (hintRows.length) {
        var glossaryText = hintRows.join(" | ");
        anchor = insertReadingArtifactAfter(anchor, "ai-translate-glossary", glossaryText);
      }
    }

    var paragraphTranslated = await translateBlockWithCache(sourceLang, state.options.targetLang || "zh", sourceText);
    if (!paragraphTranslated) {
      return;
    }
    insertReadingArtifactAfter(anchor, "ai-translate-reading-box", paragraphTranslated);
  }

  async function processVisibleReadingCandidates() {
    if (!state.readingModeEnabled) {
      return;
    }

    var candidates = collectReadingCandidates(true);
    var maxBatch = Constants.UI.READING_MODE_BATCH_SIZE;
    for (var i = 0; i < candidates.length && i < maxBatch; i += 1) {
      var item = candidates[i];
      state.readingProcessedElements.add(item.element);
      state.readingProcessedKeyMap[item.key] = true;
      item.element.setAttribute("data-ai-reading-done", "1");
      await renderReadingHints(item.element, item.text);
    }
  }

  function bindReadingModeListeners() {
    var debounced = debounce(function () {
      processVisibleReadingCandidates();
    }, Constants.UI.SCROLL_TRANSLATE_DEBOUNCE_MS);

    state.readingScrollHandler = debounced;
    state.readingResizeHandler = debounced;

    global.addEventListener("scroll", state.readingScrollHandler, { passive: true });
    global.addEventListener("resize", state.readingResizeHandler);

    state.readingMutationObserver = new MutationObserver(function () {
      debounced();
    });
    state.readingMutationObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function unbindReadingModeListeners() {
    if (state.readingScrollHandler) {
      global.removeEventListener("scroll", state.readingScrollHandler);
      state.readingScrollHandler = null;
    }
    if (state.readingResizeHandler) {
      global.removeEventListener("resize", state.readingResizeHandler);
      state.readingResizeHandler = null;
    }
    if (state.readingMutationObserver) {
      state.readingMutationObserver.disconnect();
      state.readingMutationObserver = null;
    }
  }

  async function enableReadingMode() {
    removeReadingArtifacts();
    state.readingProcessedElements = new WeakSet();
    state.readingProcessedKeyMap = {};
    state.readingModeEnabled = true;
    bindReadingModeListeners();
    await processVisibleReadingCandidates();
    await setPageState({ readingMode: true, pageTranslate: false, activeMode: "reading_mode" });
  }

  async function disableReadingMode() {
    unbindReadingModeListeners();
    removeReadingArtifacts();
    state.readingProcessedElements = new WeakSet();
    state.readingProcessedKeyMap = {};
    state.readingModeEnabled = false;
    await setPageState({ readingMode: false, activeMode: state.pageTranslateEnabled ? "page_translate" : "none" });
  }

  async function togglePageTranslateMutual() {
    if (state.pageTranslateEnabled) {
      await disablePageTranslate();
      return;
    }

    if (state.readingModeEnabled) {
      await disableReadingMode();
    }

    await enablePageTranslate();
  }

  async function toggleReadingModeMutual() {
    if (state.readingModeEnabled) {
      await disableReadingMode();
      return;
    }

    if (state.pageTranslateEnabled) {
      await disablePageTranslate();
    }

    await enableReadingMode();
  }

  function getWordAtPoint(x, y) {
    var range = null;
    if (document.caretRangeFromPoint) {
      range = document.caretRangeFromPoint(x, y);
    } else if (document.caretPositionFromPoint) {
      var pos = document.caretPositionFromPoint(x, y);
      if (pos) {
        range = document.createRange();
        range.setStart(pos.offsetNode, pos.offset);
      }
    }

    if (!range || !range.startContainer || range.startContainer.nodeType !== Node.TEXT_NODE) {
      return "";
    }

    var text = range.startContainer.nodeValue || "";
    var offset = range.startOffset;
    var left = offset;
    var right = offset;

    while (left > 0 && /[a-zA-Z'-]/.test(text[left - 1])) {
      left -= 1;
    }
    while (right < text.length && /[a-zA-Z'-]/.test(text[right])) {
      right += 1;
    }

    return text.slice(left, right).trim();
  }

  function attachOrReplaceBox(selectorClass, hostElement, text) {
    var existing = hostElement.querySelector("." + selectorClass);
    if (existing) {
      existing.textContent = text;
      return existing;
    }

    var box = document.createElement("div");
    box.className = selectorClass;
    box.textContent = text;
    hostElement.appendChild(box);
    return box;
  }

  function isTranslateArtifactTarget(target) {
    if (!target || !target.closest) {
      return false;
    }

    return Boolean(target.closest(".ai-translate-page-box,.ai-translate-reading-box,.ai-translate-glossary,.ai-translate-hover-box,.ai-translate-selection-box"));
  }

  function findTextHost(target) {
    if (!target || !target.closest) {
      return null;
    }
    if (isTranslateArtifactTarget(target)) {
      return null;
    }
    return target.closest("p,li,h1,h2,h3,h4,blockquote,article,section,div");
  }

  function bindHoverTranslation() {
    document.addEventListener("mousemove", function (event) {
      if (!state.readingModeEnabled) {
        return;
      }

      if (state.hoverTimer) {
        clearTimeout(state.hoverTimer);
      }

      var host = findTextHost(event.target);
      if (!host) {
        return;
      }

      state.hoverTimer = setTimeout(async function () {
        var word = getWordAtPoint(event.clientX, event.clientY);
        if (!word || word.length < 2) {
          return;
        }

        var hoverKey = host.tagName + ":" + word;
        if (hoverKey === state.lastHoverKey) {
          return;
        }

        var sourceLang = state.options.pageSourceLang || "auto";
        if (sourceLang === "auto") {
          sourceLang = await TranslationGateway.detectLanguage(word);
        }

        var translated = await translateBlockWithCache(sourceLang, state.options.targetLang || "zh", word);
        if (!translated) {
          return;
        }

        state.lastHoverKey = hoverKey;
        attachOrReplaceBox("ai-translate-hover-box", host, word + " -> " + translated);
      }, Constants.UI.HOVER_DELAY_MS);
    }, { passive: true });
  }

  function findSelectionHost() {
    var selection = global.getSelection ? global.getSelection() : null;
    if (!selection || selection.rangeCount === 0) {
      return null;
    }

    var range = selection.getRangeAt(0);
    var node = range.commonAncestorContainer;
    if (!node) {
      return null;
    }

    var element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    return findTextHost(element);
  }

  function bindSelectionTranslation() {
    document.addEventListener("mouseup", async function () {
      if (!state.readingModeEnabled) {
        return;
      }

      var selection = global.getSelection ? global.getSelection() : null;
      if (selection && selection.rangeCount > 0) {
        var node = selection.getRangeAt(0).commonAncestorContainer;
        var checkElement = node && node.nodeType === Node.ELEMENT_NODE ? node : (node ? node.parentElement : null);
        if (checkElement && isTranslateArtifactTarget(checkElement)) {
          return;
        }
      }

      var selected = String(selection ? selection.toString() : "").trim();
      if (!selected || selected.length < 2 || selected.length > 140) {
        return;
      }

      var sourceLang = state.options.pageSourceLang || "auto";
      if (sourceLang === "auto") {
        sourceLang = await TranslationGateway.detectLanguage(selected);
      }

      var translated = await translateBlockWithCache(sourceLang, state.options.targetLang || "zh", selected);
      if (!translated) {
        return;
      }

      var host = findSelectionHost() || document.body;
      attachOrReplaceBox("ai-translate-selection-box", host, selected + " -> " + translated);
    });
  }

  function showForeignLanguageBanner(sourceLang, nativeLang) {
    var banner = document.createElement("div");
    banner.className = "ai-translate-banner";
    banner.textContent = "检测到页面语言为 " + sourceLang + "，你的常用语言是 " + nativeLang + "。";

    var button = document.createElement("button");
    button.textContent = "立即翻译";
    button.addEventListener("click", async function () {
      await togglePageTranslateMutual();
      if (banner.parentNode) {
        banner.parentNode.removeChild(banner);
      }
    });

    var close = document.createElement("button");
    close.textContent = "关闭";
    close.addEventListener("click", function () {
      if (banner.parentNode) {
        banner.parentNode.removeChild(banner);
      }
    });

    banner.appendChild(button);
    banner.appendChild(close);
    document.body.appendChild(banner);
  }

  async function maybeSuggestAutoTranslate() {
    if (!state.options.autoTranslateForeignPage) {
      return;
    }

    var bodyText = String(document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
    if (!bodyText) {
      return;
    }

    var pageLang = await TranslationGateway.detectLanguage(bodyText.slice(0, 800));
    if (!pageLang || pageLang === "auto") {
      return;
    }

    var nativeLang = (navigator.language || "en").slice(0, 2).toLowerCase();
    if (pageLang !== nativeLang) {
      showForeignLanguageBanner(pageLang, nativeLang);
    }
  }

  chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    (async function handle() {
      if (!request || !request.type) {
        return sendResponse({ ok: false });
      }

      if (request.type === Constants.MESSAGE.TOGGLE_PAGE_TRANSLATE) {
        await togglePageTranslateMutual();
        return sendResponse({
          ok: true,
          pageTranslate: state.pageTranslateEnabled,
          readingMode: state.readingModeEnabled,
          activeMode: state.pageTranslateEnabled ? "page_translate" : (state.readingModeEnabled ? "reading_mode" : "none")
        });
      }

      if (request.type === Constants.MESSAGE.TOGGLE_READING_MODE) {
        await toggleReadingModeMutual();
        return sendResponse({
          ok: true,
          pageTranslate: state.pageTranslateEnabled,
          readingMode: state.readingModeEnabled,
          activeMode: state.pageTranslateEnabled ? "page_translate" : (state.readingModeEnabled ? "reading_mode" : "none")
        });
      }

      if (request.type === "translate_selection_now") {
        var selected = String(global.getSelection ? global.getSelection().toString() : "").trim();
        if (!selected) {
          Logger.warn("content", "selection translate requested but no selected text");
          return sendResponse({ ok: false, reason: "empty_selection" });
        }

        var sourceLang = state.options.pageSourceLang || "auto";
        if (sourceLang === "auto") {
          sourceLang = await TranslationGateway.detectLanguage(selected);
        }

        var translated = await translateBlockWithCache(sourceLang, state.options.targetLang || "zh", selected);
        if (!translated) {
          return sendResponse({ ok: false, reason: "translate_failed" });
        }

        alert(selected + "\n\n" + translated);
        return sendResponse({ ok: true });
      }

      return sendResponse({ ok: false, reason: "unknown_type" });
    })();

    return true;
  });

  async function bootstrap() {
    state.options = await getOptions();
    await loadTranslationCache();
    bindHoverTranslation();
    bindSelectionTranslation();
    await maybeSuggestAutoTranslate();
    await setPageState({ pageTranslate: false, readingMode: false, activeMode: "none" });
  }

  bootstrap();
})(globalThis);
