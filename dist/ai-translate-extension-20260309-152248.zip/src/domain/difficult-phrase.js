(function initDifficultPhrase(global) {
  var root = global.AITranslate = global.AITranslate || {};

  function normalizeWords(text) {
    return String(text || "")
      .toLowerCase()
      .replace(/[^a-zA-Z\s'-]/g, " ")
      .split(/\s+/)
      .filter(Boolean);
  }

  function extractCandidates(text) {
    var words = normalizeWords(text);
    var dict = {};
    for (var i = 0; i < words.length; i += 1) {
      var word = words[i];
      if (word.length < 8) {
        continue;
      }
      if (!dict[word]) {
        dict[word] = 0;
      }
      dict[word] += 1;
    }

    return Object.keys(dict)
      .sort(function (a, b) {
        if (dict[a] !== dict[b]) {
          return dict[b] - dict[a];
        }
        return b.length - a.length;
      })
      .slice(0, 5);
  }

  root.DifficultPhrase = {
    extractCandidates: extractCandidates
  };
})(globalThis);
