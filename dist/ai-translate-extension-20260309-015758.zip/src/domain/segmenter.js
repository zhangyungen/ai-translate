(function initSegmenter(global) {
  var root = global.AITranslate = global.AITranslate || {};

  function splitByPunctuation(text) {
    return text
      .replace(/\s+/g, " ")
      .trim()
      .split(/(?<=[.!?。！？；;:：])\s+/)
      .filter(Boolean);
  }

  function splitLongSentence(sentence, maxLen) {
    if (sentence.length <= maxLen) {
      return [sentence];
    }

    var chunks = [];
    var words = sentence.split(/\s+/);
    var buffer = "";

    for (var i = 0; i < words.length; i += 1) {
      var next = buffer ? (buffer + " " + words[i]) : words[i];
      if (next.length > maxLen && buffer) {
        chunks.push(buffer);
        buffer = words[i];
      } else {
        buffer = next;
      }
    }

    if (buffer) {
      chunks.push(buffer);
    }

    return chunks;
  }

  function segmentText(text) {
    var raw = String(text || "").trim();
    if (!raw) {
      return [];
    }

    var sentences = splitByPunctuation(raw);
    var segments = [];

    for (var i = 0; i < sentences.length; i += 1) {
      var sub = splitLongSentence(sentences[i], 120);
      segments = segments.concat(sub);
    }

    return segments.filter(Boolean);
  }

  root.Segmenter = {
    segmentText: segmentText,
    toDelimitedText: function (text, delimiter) {
      var pieces = segmentText(text);
      return pieces.join(delimiter || "||||");
    }
  };
})(globalThis);
